package com.hwhhhh.wordbook.util.searchView;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class mySearchView extends FrameLayout{
    private Context mContext;

    public mySearchView(Context context) {
        super(context);
    }

    public mySearchView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public mySearchView(Context context, AttributeSet attributeSet, int defStyle) {
        super(context, attributeSet, defStyle);
    }

}
